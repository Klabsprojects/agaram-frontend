import { ChangeDetectorRef, Component, ElementRef, OnInit, TRANSLATIONS } from '@angular/core';
// import Chart from 'chart.js/auto';
import { LeaveTransferService } from '../forms/forms.service';
import { employeeFilterList } from '../officer-profile/officer.model';
import { Router } from '@angular/router';
import { employeeHistory } from './dashboard.model';
import { DatePipe } from '@angular/common';
import { FormBuilder, FormGroup, NgForm } from '@angular/forms';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  public chart: any;
  department:any[]=[];
  designation:any[]=[];
  postingIn: any[]=[];
  public employeeFilterDataMl = new employeeFilterList();
  public employeeFilterData : any[]=[];
  public gender:any[] = [];
  public genderValue:any;
  filteredOptions: any[] = [];
  showDropdown = false;
  selectedOption: any;
  selectedEmpOption:string = '';
  selectedFilter: string = '';
  showName= true;
  showGender = true;
  showPosting = true;
  showBatch = true;
  showDepartment = true;
  showDesignation = true;
  showFrom = false;
  showTo = false;
  showTable = true;
  nameReadonly: boolean = false;
  postingInReadonly: boolean = false;
  departmentReadonly: boolean = false;
  designationReadonly: boolean = false;
  showLocation = true;
  fromDate: string='';
  toDate: string = '';
  name:string='';
  postingin:string='';
  departmentValue:string='';
  tableData:any[]=[];
  showMainTitle = true;

  //Dashboard icon
  showActive = false;
  showretiredOfficer = false;
  showMale = false;
  showFemale = false;
  showSec = false;
  showOutsideChennai = false;
  showOutsideSec = false;
  showChennai = false;
  showCollector = false;
  showSub = false;
  showAsst = false;
  showAdditional = false;
  showComm = false;
  showFilter = true;
  showCard = true;
  showtable = false;
  showIcon = false;

  ActiveEmployeeCount = '';
  RetiredEmployeeCount = '';
  TotalOfficerCount ='';
  TotalGender='';
  maleEmployeeCount = '';
  femaleEmployeeCount = '';
  totalCountLocation='';
  chennaiOfficerCount = '';
  outsideChennaiOfficerCount = '';
  secretariatCount = '';
  outsideSecretariatCount = '';
  totalSecretariatCount = '';
  totalCollectors = '';
  collectorCount = '';
  subCollectorCount = '';
  asstCollectorsCount = '';
  additionalCollectorCount = '';
  commissionerCount = '';
  filterText: any;
  state:any[]=[];

  pageSize: number = 10;
  pageSizeOptions: number[] = [1, 10, 15, 20];
  currentPage: number = 1;
  // filteredEmployeeLists: any[] = []; // Your filtered list
  popupVisible: boolean = false;
  base64ImageData: string = '';
  employeeHistory = new employeeHistory();
  filterForm!:FormGroup;
  selectedBatchOption : string='';
  showBatchDropdown = false;
  filteredBatchOptions : any;
  firstIndex: any = '';
  remainingIndices:any[]=[];
  showAdvanceSearch = true;
  showPeriod = true;
  showDesignationDropdown = false;

  constructor(private fb:FormBuilder,private datePipe: DatePipe,private router:Router, private leaveTransfer:LeaveTransferService, private el: ElementRef,private cdr: ChangeDetectorRef){}

  ngOnInit(): void {
    this.getDashboard();
   const role = localStorage.getItem('loginAs');
    if(role!="Officer"){
      this.showCard = true;
      this.showAdvanceSearch = true;
      this.showPeriod = true;
      this.showDesignationDropdown = false;
    }
    else{
      this.showCard  = false;
      this.showAdvanceSearch = false;
      this.showPeriod = false;
      this.showDesignationDropdown = true;
    }
    // this.createBarChart();
    // this.createLineChart();

    this.filterForm = this.fb.group({
      name:[''],
      postingIn:[''],
      department:[''],
      batch:[''],
      // period:{
      //   fromDate:[''],
      //   toDate:['']
      // }
      period: this.fb.group({
        fromDate: [''],
        toDate: ['']
      })
    });

    this.leaveTransfer.getData().subscribe((res: any[]) => {
      res.forEach((item) => {
        if(item.category_type == "posting_in"){
          this.postingIn.push({label:item.category_name,value:item._id});
        }
        if(item.category_type == "gender"){
          this.gender.push(item);
        }
        });
      });

      this.leaveTransfer.getDepartmentData().subscribe((res: any[]) => {
        res.filter((data: any) => {
          this.department.push({ label: data.department_name, value: data._id });
        });
      });

      this.leaveTransfer.getDesignations().subscribe((res:any)=>{
        res.results.filter((data:any)=>{
          this.designation.push({label:data.designation_name, value:data._id});
        })
      })

    //   this.leaveTransfer.getEmployeeList().subscribe((res:any)=>{
    //     this.employeeFilterData = res.results;
    //     this.employeeFilterData.forEach((employee: any) => {
    //       var dateOfJoining = new Date(employee.dateOfJoining);
    //       employee.dateOfJoining= dateOfJoining.toISOString().split('T')[0];
    //       // var options = { day: '2-digit', month: '2-digit', year: '2-digit' };
    //       // var formattedDate = dateOfJoining.toLocaleDateString('en-GB', options);
    //       // formattedDate = formattedDate.replace(/\//g, '-');

    //         this.genderValue = this.gender.find((gender: any) => gender._id === employee.gender);
    //         if (this.genderValue) {
    //             employee.gender = this.genderValue.category_name;
    //         } 
    //     });
    // });
  }

  advanceSearch(){
    this.router.navigate(['advance-search']);
  }

  viewInfo(data: any) {
    this.popupVisible = true;
    this.remainingIndices = [];
    this.firstIndex = '';
    this.leaveTransfer.getEmployeeHistory(data).subscribe((res: any) => {
        res.results.forEach((item: any) => {
          if (item._id == data) {
                this.leaveTransfer.getData().subscribe((response: any) => {
                    response.forEach((ele: any) => {
                        if (ele.category_type == "state") {
                          if(ele._id == item.state){
                            this.employeeHistory.state = ele.category_name;
                          }
                        }
                      });  
                    item.employeeHistory.forEach((element: any, index: number) => {
                      if (index === 0) {
                        this.firstIndex = element.transferOrPostingEmployeesList;
                        if (element.category_type == "posting_in") {
                          if(element._id == element.transferOrPostingEmployeesList.toPostingInCategoryCode){
                          this.firstIndex.posting = element.category_name;
                          }
                        }
                       this.department.forEach((elem:any)=>{
                        if(elem.value == element.transferOrPostingEmployeesList.toDepartmentId){
                          this.firstIndex.toDepartmentId = elem.label;
                          }
                       });

                       this.designation.forEach((elem:any)=>{
                        if(elem.value == element.transferOrPostingEmployeesList.toDesignationId){
                          this.firstIndex.toDesignationId = elem.label;
                          }
                       });
                      } 
                      

                      if (index != 0) {
                        const postingIn = this.postingIn.find((data: any) => data.value === element.transferOrPostingEmployeesList.toPostingInCategoryCode);
                        const department = this.department.find((data: any) => data.value === element.transferOrPostingEmployeesList.toDepartmentId);
                        const designation = this.designation.find((data: any) => data.value === element.transferOrPostingEmployeesList.toDesignationId);
                        this.remainingIndices.push({
                          postingIn: postingIn ? postingIn.label : '',
                          department: department ? department.label : '',
                          designation: designation ? designation.label : ''
                        });
                        console.log(this.remainingIndices);
                      }
                    });
                  
                    this.employeeHistory.fullName = item.fullName;
                    this.employeeHistory.mobileNo1 = item.mobileNo1;
                    this.employeeHistory.mobileNo2 = item.mobileNo2;
                    this.employeeHistory.mobileNo3 = item.mobileNo3;
                    this.employeeHistory.personalEmail = item.personalEmail;
                    this.employeeHistory.batch = item.batch;
                    this.employeeHistory.addressLine = item.addressLine;
                    this.employeeHistory.city = item.city;
                    this.employeeHistory.pincode = item.pincode;
                    this.employeeHistory.employeeId = item.employeeId;
                    this.employeeHistory.payscale = item.payscale;
                    this.employeeHistory.officeEmail = item.officeEmail;
                    this.employeeHistory.caste = item.caste;
                    const originalDate = item.dateOfBirth;
                    this.employeeHistory.dateOfBirth = this.datePipe.transform(originalDate, 'dd/MM/yyyy');
                    const dateOfJoining = item.dateOfJoining;
                    this.employeeHistory.dateOfJoining = this.datePipe.transform(dateOfJoining, 'dd/MM/yyyy');
                    const dateOfRetirement = item.dateOfRetirement;
                    this.employeeHistory.dateOfRetirement = this.datePipe.transform(dateOfRetirement, 'dd/MM/yyyy');
                    // const binaryData = new Uint8Array(item.photo.data);
                    if (item.photo && item.photo.data) {
                      const binaryData = new Uint8Array(item.photo.data);
                      this.base64ImageData = this.arrayBufferToBase64(binaryData);
                    }
                });
            }
        });
    });
}

arrayBufferToBase64(buffer: Uint8Array): string {
    let binary = '';
    const len = buffer.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(buffer[i]);
    }
    return window.btoa(binary);
  }

  getImageSource(base64ImageData: string): string {
    const imageType = base64ImageData.startsWith('data:image/png') ? 'png' :
                      base64ImageData.startsWith('data:image/jpeg') ? 'jpeg' :
                      base64ImageData.startsWith('data:image/jpg') ? 'jpg' : '';
    return `data:image/${imageType};base64,${base64ImageData}`;
  }

  closePopup() {
    this.popupVisible = false;
  }

  onInput(event: any, field: string) {
    const inputValue = event.target.value.trim(); 
    if (!inputValue) {
      this.showDropdown = false;
      return;
    }
    this.leaveTransfer.getEmployeeList().subscribe((res: any) => {
      if (res && res.results) {
        const mergedOptions: { name: string, id: string }[] = res.results.map((item: any) => ({
          name: item.fullName,
          id: item.employeeId
        }));
        this.filteredOptions = mergedOptions.filter(option => option.name.toLowerCase().includes(inputValue.toLowerCase()));
        this.showDropdown = this.filteredOptions.length > 0; 
      } else {
        console.error('Invalid API response:', res);
      }
    }, error => {
      console.error('API request failed:', error);
    });
  }
 
selectOption(option: { name: string, id: string }) {
  const payload: any = { name: option.name };

  // Add selected postingIn if available
  const selectedPostingIn = this.filterForm.get('postingIn')?.value;
  if (selectedPostingIn && selectedPostingIn.length > 0) {
    payload.postingIn = selectedPostingIn;
  }

  // Add selected department if available
  const selectedDepartment = this.filterForm.get('department')?.value;
  if (selectedDepartment && selectedDepartment.length > 0) {
    payload.department = selectedDepartment;
  }

  // Add selected batch if available
  const selectedBatch = this.selectedBatchOption;
  if (selectedBatch && selectedBatch.length > 0) {
    payload.batch = selectedBatch;
  }

  // Add period if available
  const period = this.filterForm.get('period')?.value;
  if (period && period.fromDate && period.toDate) {
    payload.period = {
      fromDate: period.fromDate,
      toDate: period.toDate
    };
  }

  this.selectedOption = option.name;
  this.leaveTransfer.employeeFilter(payload).subscribe((response: any) => {
    console.log(payload);
  this.employeeFilterData = response.results.empList;

    // Get Secretariat Data
    this.leaveTransfer.getData().subscribe((res: any) => {
    this.postingIn = res.filter((item: any) => item.category_type === "posting_in")
                          .map((item: any) => ({ label: item.category_name, value: item._id }));

      const matchingSecretary = this.postingIn.find(item => item.value === response.results.empList.find((data: any) => data.toPostingInCategoryCode)?.toPostingInCategoryCode);
      if (matchingSecretary) {
        this.employeeFilterData.forEach(data => {
          data.posting = matchingSecretary.label;
        });
      }
    });

    // Get Department Data
    this.leaveTransfer.getDepartmentData().subscribe((departmentRes: any) => {
      this.department = departmentRes.map((data: any) => ({ label: data.department_name, value: data._id }));
      const matchingDepartment = this.department.find(item => item.value === response.results.empList.find((data: any) => data.toDepartmentId)?.toDepartmentId);
      if (matchingDepartment) {
        this.employeeFilterData.forEach(data => {
          data.department = matchingDepartment.label;
        });
      }
    });

    // Get Designation Data
    this.leaveTransfer.getDesignations().subscribe((designationRes: any) => {
      this.designation = designationRes.results.map((data: any) => ({ label: data.designation_name, value: data._id }));

      const matchingDesignation = this.designation.find(item => item.value === response.results.empList.find((data: any) => data.toDesignationId)?.toDesignationId);
      if (matchingDesignation) {
        this.employeeFilterData.forEach(data => {
          data.designation = matchingDesignation.label;
        });
      }
    });

  }, error => {
    console.error('Employee filter request failed:', error);
  });

  this.postingInReadonly = true;
  // this.departmentReadonly = true;
  this.designationReadonly = true;
  // this.showTable = this.filteredOptions.length > 0;
  this.showName = !this.showTable;
  this.showGender = false;
  this.showPosting = this.showTable;
  this.showBatch = this.showTable;
  this.showDepartment = this.showTable;
  this.showDesignation = this.showTable;
  this.showFrom = this.showTable;
  this.showTo = this.showTable;
  this.showDropdown = false;
}

getDepartment(event:any){
  const payload :any= { postingIn: event.target.value };
  // this.department = [];

   // Add selected Name if available
   const selectedName = this.selectedOption;
   if (selectedName && selectedName.length > 0) {
     payload.name = selectedName;
   }
 
   // Add selected department if available
   const selectedDepartment = this.filterForm.get('department')?.value;
   if (selectedDepartment && selectedDepartment.length > 0) {
     payload.department = selectedDepartment;
   }
 
   // Add selected batch if available
   const selectedBatch = this.selectedBatchOption;
   if (selectedBatch && selectedBatch.length > 0) {
     payload.batch = selectedBatch;
   }
 
   // Add period if available
   const period = this.filterForm.get('period')?.value;
   if (period && period.fromDate && period.toDate) {
     payload.period = {
       fromDate: period.fromDate,
       toDate: period.toDate
     };
   }


    this.leaveTransfer.employeeFilter(payload).subscribe((response: any) => {
      console.log(payload);
      if (response.results.empList.length > 0) {
        this.employeeFilterData = response.results.empList;
        console.log(this.employeeFilterData);

        //Get Secretariat Data
  this.leaveTransfer.getData().subscribe((res: any) => {
    const matchingSecretary = this.postingIn.find(item => item.value === response.results.empList.find((data:any) => data.toPostingInCategoryCode)?.toPostingInCategoryCode);
    if (matchingSecretary) {
      this.employeeFilterData.forEach(data => {
        data.posting = matchingSecretary.label;
      });
    }
  });

  //Get Department Data
  this.leaveTransfer.getDepartmentData().subscribe((departmentRes: any) => {
    departmentRes.forEach((data: any) => {
      this.department.push({ label: data.department_name, value: data._id });
    });

    this.employeeFilterData.forEach(data => {
      const matchingDepartment = this.department.find(item => item.value === data.toDepartmentId);
      if (matchingDepartment) {
        data.department = matchingDepartment.label;
      }
    });
  });

  // Get Designation Data
  this.leaveTransfer.getDesignations().subscribe((designationRes: any) => {
    designationRes.results.forEach((data: any) => {
      this.designation.push({ label: data.designation_name, value: data._id });
    });

    this.employeeFilterData.forEach(data => {
      const matchingDesignation = this.designation.find(item => item.value === data.toDesignationId);
      if (matchingDesignation) {
        data.designation = matchingDesignation.label;
      }
    });
  });

        this.showTable = true;
        this.showName = true;
        this.showGender = true;
        this.showBatch = true;
        this.showDepartment = true;
        this.showDesignation = true;
      } 
      else if(response.results.empList.length==0){
        this.employeeFilterData.length = 0;
      }
      // else {
      //   this.employeeFilterData = [];
      //   this.showTable = false;
      //   this.showName = false;
      //   this.showGender = false;
      //   this.showBatch = false;
      //   this.showDepartment = false;
      //   this.showDesignation = false;
      // }
    }, error => {
      console.error('API request failed:', error);
    });
    
  }


  getDesignation(event:any){
    const payload :any = {department:event.target.value}
    this.designation = [];

  // Add selected Name if available
   const selectedName = this.selectedOption;
   if (selectedName && selectedName.length > 0) {
     payload.name = selectedName;
   }
 
   // Add selected posting In if available
   const selectedPostingIn = this.filterForm.get('postingIn')?.value;
   if (selectedPostingIn && selectedPostingIn.length > 0) {
     payload.postingIn = selectedPostingIn;
   }
 
   // Add selected batch if available
   const selectedBatch = this.selectedBatchOption;
   if (selectedBatch && selectedBatch.length > 0) {
     payload.batch = selectedBatch;
   }
 
   // Add period if available
   const period = this.filterForm.get('period')?.value;
   if (period && period.fromDate && period.toDate) {
     payload.period = {
       fromDate: period.fromDate,
       toDate: period.toDate
     };
   }

    this.leaveTransfer.employeeFilter(payload).subscribe((response: any) => {
      console.log(payload);
      if (response.results.empList.length > 0) {
        this.employeeFilterData = response.results.empList;
        //Get Department Data
  this.leaveTransfer.getDepartmentData().subscribe((departmentRes: any) => {
    departmentRes.filter((data: any) => {
      this.department.push({ label: data.department_name, value: data._id });
    });
  const matchingDepartment = this.department.find(item => item.value === response.results.empList.find((data:any) => data.toDepartmentId)?.toDepartmentId);
    if (matchingDepartment) {
      this.employeeFilterData.forEach(data => {
        data.department = matchingDepartment.label;
      });
    }
  });
  
  // Get Designation Data
  this.leaveTransfer.getDesignations().subscribe((designationRes: any) => {
    designationRes.results.filter((data: any) => {
      this.designation.push({ label: data.designation_name, value: data._id });
    });

    const matchingDesignation = this.designation.find(item => item.value === response.results.empList.find((data:any) => data.toDesignationId)?.toDesignationId);
    if (matchingDesignation) {
      this.employeeFilterData.forEach(data => {
        data.designation = matchingDesignation.label;
      });
    }
  });

        this.showTable = true;
        this.showName = true;
        this.showGender = true;
        this.showBatch = true;
        this.showDepartment = true;
        this.showDesignation = true;
      } 
      else if(response.results.empList.length == 0){
        this.employeeFilterData.length = 0;
      }
    }, error => {
      console.error('API request failed:', error);
    });
  }


  getFromDate(event:any){
    const payload :any = {fromDate:event.target.value}

  // Add selected Name if available
   const selectedName = this.selectedOption;
   if (selectedName && selectedName.length > 0) {
     payload.name = selectedName;
   }
 
   // Add selected posting In if available
   const selectedPostingIn = this.filterForm.get('postingIn')?.value;
   if (selectedPostingIn && selectedPostingIn.length > 0) {
     payload.postingIn = selectedPostingIn;
   }
 
   // Add selected batch if available
   const selectedBatch = this.selectedBatchOption;
   if (selectedBatch && selectedBatch.length > 0) {
     payload.batch = selectedBatch;
   }
 
   

    this.leaveTransfer.employeeFilter(payload).subscribe((response: any) => {
      console.log(payload);
      if (response.results.empList.length > 0) {
        this.employeeFilterData = response.results.empList;
        //Get Department Data
  this.leaveTransfer.getDepartmentData().subscribe((departmentRes: any) => {
    departmentRes.filter((data: any) => {
      this.department.push({ label: data.department_name, value: data._id });
    });
  const matchingDepartment = this.department.find(item => item.value === response.results.empList.find((data:any) => data.toDepartmentId)?.toDepartmentId);
    if (matchingDepartment) {
      this.employeeFilterData.forEach(data => {
        data.department = matchingDepartment.label;
      });
    }
  });
  
  // Get Designation Data
  this.leaveTransfer.getDesignations().subscribe((designationRes: any) => {
    designationRes.results.filter((data: any) => {
      this.designation.push({ label: data.designation_name, value: data._id });
    });

    const matchingDesignation = this.designation.find(item => item.value === response.results.empList.find((data:any) => data.toDesignationId)?.toDesignationId);
    if (matchingDesignation) {
      this.employeeFilterData.forEach(data => {
        data.designation = matchingDesignation.label;
      });
    }
  });

        this.showTable = true;
        this.showName = true;
        this.showGender = true;
        this.showBatch = true;
        this.showDepartment = true;
        this.showDesignation = true;
      } 
      else if(response.results.empList.length == 0){
        this.employeeFilterData.length = 0;
      }
    }, error => {
      console.error('API request failed:', error);
    });
  }

  getToDate(event:any){
    const payload :any = {toDate:event.target.value}
    this.designation = [];

  // Add selected Name if available
   const selectedName = this.selectedOption;
   if (selectedName && selectedName.length > 0) {
     payload.name = selectedName;
   }
 
   // Add selected posting In if available
   const selectedPostingIn = this.filterForm.get('postingIn')?.value;
   if (selectedPostingIn && selectedPostingIn.length > 0) {
     payload.postingIn = selectedPostingIn;
   }
 
   // Add selected batch if available
   const selectedBatch = this.selectedBatchOption;
   if (selectedBatch && selectedBatch.length > 0) {
     payload.batch = selectedBatch;
   }
 
   // Add period if available
   const period = this.filterForm.get('period')?.value;
   if (period && period.fromDate && period.toDate) {
     payload.period = {
       fromDate: period.fromDate,
       toDate: period.toDate
     };
   }

    this.leaveTransfer.employeeFilter(payload).subscribe((response: any) => {
      console.log(payload);
      if (response.results.empList.length > 0) {
        this.employeeFilterData = response.results.empList;
        //Get Department Data
  this.leaveTransfer.getDepartmentData().subscribe((departmentRes: any) => {
    departmentRes.filter((data: any) => {
      this.department.push({ label: data.department_name, value: data._id });
    });
  const matchingDepartment = this.department.find(item => item.value === response.results.empList.find((data:any) => data.toDepartmentId)?.toDepartmentId);
    if (matchingDepartment) {
      this.employeeFilterData.forEach(data => {
        data.department = matchingDepartment.label;
      });
    }
  });
  
  // Get Designation Data
  this.leaveTransfer.getDesignations().subscribe((designationRes: any) => {
    designationRes.results.filter((data: any) => {
      this.designation.push({ label: data.designation_name, value: data._id });
    });

    const matchingDesignation = this.designation.find(item => item.value === response.results.empList.find((data:any) => data.toDesignationId)?.toDesignationId);
    if (matchingDesignation) {
      this.employeeFilterData.forEach(data => {
        data.designation = matchingDesignation.label;
      });
    }
  });

        this.showTable = true;
        this.showName = true;
        this.showGender = true;
        this.showBatch = true;
        this.showDepartment = true;
        this.showDesignation = true;
      } 
      else if(response.results.empList.length == 0){
        this.employeeFilterData.length = 0;
      }
    }, error => {
      console.error('API request failed:', error);
    });
  }


onBatchInput(event: any,field:string) {
  const inputValue = event.target.value.trim(); 
  if (!inputValue) {
    this.showBatchDropdown = false;
    return;
  }



  this.leaveTransfer.getEmployeeList().subscribe((res: any) => {
    if (res && res.results) {
      const groupedOptions: { [key: string]: any[] } = {};
      res.results.forEach((item: any) => {
        const batchValue = item.batch;
        if (!groupedOptions[batchValue]) {
          groupedOptions[batchValue] = [];
        }
        groupedOptions[batchValue].push({ batch: batchValue });
      });

      // Transforming groupedOptions into array
      this.filteredBatchOptions = Object.keys(groupedOptions).map(key => ({
        batch: key,
        items: groupedOptions[key]
      }));

      this.showBatchDropdown = this.filteredBatchOptions.length > 0;
    } else {
      console.error('Invalid API response:', res);
    }
  }, error => {
    console.error('API request failed:', error);
  });
}

selectBatchOption(option: { batch: string}) {
const payload :any= { batch: option.batch };
// const payloadString = JSON.stringify(payload);

// Add selected Name if available
const selectedName = this.selectedOption;
if (selectedName && selectedName.length > 0) {
  payload.name = selectedName;
}

// Add selected department if available
const selectedDepartment = this.filterForm.get('department')?.value;
if (selectedDepartment && selectedDepartment.length > 0) {
  payload.department = selectedDepartment;
}

// Add selected posting In if available
const selectedPostingIn = this.filterForm.get('postingIn')?.value;
if (selectedPostingIn && selectedPostingIn.length > 0) {
  payload.postingIn = selectedPostingIn;
}

// Add period if available
const period = this.filterForm.get('period')?.value;
if (period && period.fromDate && period.toDate) {
  payload.period = {
    fromDate: period.fromDate,
    toDate: period.toDate
  };
}



this.selectedBatchOption = option.batch;
this.leaveTransfer.employeeFilter(payload).subscribe((response: any) => {
  this.employeeFilterData = response.results.empList;

  //Get Secretariat Data
  this.leaveTransfer.getData().subscribe((res: any) => {
    res.forEach((item:any) => {
      if(item.category_type == "posting_in"){
        this.postingIn.push({label:item.category_name,value:item._id});
      }
    });
    const matchingSecretary = this.postingIn.find(item => item.value === response.results.empList.find((data:any) => data.toPostingInCategoryCode)?.toPostingInCategoryCode);
    if (matchingSecretary) {
      this.employeeFilterData.forEach(data => {
        data.posting = matchingSecretary.label;
      });
    }
  });

  //Get Department Data
  this.leaveTransfer.getDepartmentData().subscribe((departmentRes: any) => {
    departmentRes.forEach((data: any) => {
      this.department.push({ label: data.department_name, value: data._id });
    });

    this.employeeFilterData.forEach(data => {
      const matchingDepartment = this.department.find(item => item.value === data.toDepartmentId);
      if (matchingDepartment) {
        data.department = matchingDepartment.label;
      }
    });
  });

  // Get Designation Data
  this.leaveTransfer.getDesignations().subscribe((designationRes: any) => {
    designationRes.results.forEach((data: any) => {
      this.designation.push({ label: data.designation_name, value: data._id });
    });

    this.employeeFilterData.forEach(data => {
      const matchingDesignation = this.designation.find(item => item.value === data.toDesignationId);
      if (matchingDesignation) {
        data.designation = matchingDesignation.label;
      }
    });
  });
}, error => {
  console.error('Employee filter request failed:', error);
});


this.postingInReadonly = true;
// this.departmentReadonly = true;
this.designationReadonly = true;
this.showTable = this.filteredBatchOptions.length > 0;
// this.showName = !this.showTable;
this.showGender = false;
this.showPosting = this.showTable;
this.showBatch = this.showTable;
this.showName = true;
this.showDepartment = this.showTable;
this.showDesignation = this.showTable;
this.showFrom = this.showTable;
this.showTo = this.showTable;
this.showBatchDropdown = false;
}


getValue(event: any, controlName: string): void {
  const value = event.target.value;
  console.log(event.target.value);
  const payload: any = {};
    Object.keys(this.filterForm.controls).forEach(key => {
    const controlValue = this.filterForm.get(key)?.value;
    if (controlValue !== '' && controlValue !== null && controlValue !== undefined) {
      payload[key] = controlValue;
    }
  });

  // this.leaveTransfer.employeeFilter(payload).subscribe((res: any) => {
      
  //     res.results.empList.forEach((ele:any)=>{
  //     const postingIn = this.postingIn.find((data: any) => data.value === ele.toPostingInCategoryCode);
  //     const department = this.department.find((data: any) => data.value === ele.toDepartmentId);
  //     const designation = this.designation.find((data: any) => data.value === ele.toDesignationId);
  //     const gender = this.gender.find((data:any)=>data.value === ele.gender);
  //     ele.postingInLabel = postingIn ? postingIn.label : '';
  //     ele.departmentLabel = department ? department.label : '';
  //     ele.designationLabel = designation ? designation.label : '';
  //     ele.genderLabel = gender ? gender.label : '';
  //     });
  //     this.tableData = res.results.empList;

      
  // });
}



get filteredEmployeeList() {
  const filterText = (this.filterText || '').trim().toLowerCase();
  if (filterText === '') {
    return this.tableData;
  } else {
    return this.tableData.filter(employee =>
      Object.values(employee).some((value: any) =>
        value && value.toString().toLowerCase().includes(filterText)));
  }
}

changeValue(data:any){
  if(data.target.value == "Print"){
    const printableElement = document.querySelector('.printable-content');
    console.log(printableElement);
    if (printableElement) {
      window.print();
    } else {
      console.error('Printable element not found');
    }
  }
}

pagedData() {
  const startIndex = (this.currentPage - 1) * this.pageSize;
  const endIndex = startIndex + this.pageSize;
  return this.filteredEmployeeList.slice(startIndex, endIndex);
}
get totalPages(): number {
  return Math.ceil(this.filteredEmployeeList.length / this.pageSize);
}

get pages(): number[] {
  const pagesCount = Math.min(5, this.totalPages); // Display up to 5 pages
  const startPage = Math.max(1, this.currentPage - Math.floor(pagesCount / 2));
  const endPage = Math.min(this.totalPages, startPage + pagesCount - 1);
  return Array.from({ length: endPage - startPage + 1 }, (_, i) => startPage + i);
}

prevPage() {
  if (this.currentPage > 1) {
    this.currentPage--;
  }
}

nextPage() {
  if (this.currentPage < this.totalPages) {
    this.currentPage++;
  }
}

changePageSize(size: number) {
  this.pageSize = size;
  this.currentPage = 1;
}

goToPage(page: number) {
  this.currentPage = page;
}



handleFilterChange() {
  this.cdr.detectChanges();
}


onDateChange(data:any) {
  console.log(this.fromDate,this.toDate);
  if (this.fromDate && this.toDate) {
    this.postingInReadonly = true;
  // this.departmentReadonly = true;
  this.designationReadonly = true;
  this.showName = !this.showTable;
  this.showGender = false;
  this.showPosting = this.showTable;
  this.showBatch = this.showTable;
  this.showDepartment = this.showTable;
  this.showDesignation = this.showTable;
  this.showFrom = this.showTable;
  this.showTo = this.showTable;
  this.showDropdown = false;
    this.leaveTransfer.employeeFilter(data).subscribe((res: any) => {
      this.employeeFilterData = res.results;
    }, (error) => {
      console.error('Error fetching employees:', error);
    });
  }
}





getDashboard() {
  this.leaveTransfer.getActiveOfficers().subscribe((res: any) => {
   this.ActiveEmployeeCount= res.results.empCount;
    this.leaveTransfer.getRetiresOfficers().subscribe((res: any) => {
      this.RetiredEmployeeCount= res.results.empCount;
      this.tableData = res.results.empList;
      this.TotalOfficerCount = this.ActiveEmployeeCount + this.RetiredEmployeeCount;
    });
  });

  this.leaveTransfer.getMaleEmployees().subscribe((res: any) => {
    this.maleEmployeeCount= res.results.empCount;
 
     this.leaveTransfer.getFemaleEmployees().subscribe((res: any) => {
       this.femaleEmployeeCount= res.results.empCount;
       this.TotalGender = this.maleEmployeeCount + this.femaleEmployeeCount;
     });
   });

   this.leaveTransfer.getByLocation('yes').subscribe((res: any) => {
    this.chennaiOfficerCount = res.results.empCount;
 
     this.leaveTransfer.getByLocation('no').subscribe((res: any) => {
       this.outsideChennaiOfficerCount= res.results.empCount;
       this.totalCountLocation = this.chennaiOfficerCount + this.outsideChennaiOfficerCount;
     });
   });

   this.leaveTransfer.getSecretariat('yes').subscribe((res: any) => {
    this.secretariatCount = res.results.empCount;
 
     this.leaveTransfer.getSecretariat('no').subscribe((res: any) => {
       this.outsideSecretariatCount= res.results.empCount;
       this.totalSecretariatCount = this.secretariatCount + this.outsideSecretariatCount;
     });
   });

   this.leaveTransfer.getByDesignation('Collector').subscribe((res: any) => {
   this.collectorCount = res.results.empCount;
   this.leaveTransfer.getByDesignation('Sub Collector').subscribe((res: any) => {
   this.subCollectorCount= res.results.empCount;
   this.leaveTransfer.getByDesignation('Assistant Collector').subscribe((res: any) => {
   this.asstCollectorsCount= res.results.empCount;
   this.leaveTransfer.getByDesignation('Additional Collector').subscribe((res: any) => {
   this.additionalCollectorCount= res.results.empCount;
   this.totalCollectors = this.collectorCount + this.subCollectorCount+this.asstCollectorsCount+this.additionalCollectorCount;
     });
   this.leaveTransfer.getByDesignation('Commissioner').subscribe((res: any) => {
   this.commissionerCount= res.results.empCount;
   });
   });
   });
  });
   
}


  activeOfficers(data:any){
    this.leaveTransfer.getActiveOfficers().subscribe((res: any) => {
      res.results.empList.forEach((empItem: any) => {
        this.postingIn.forEach((postingInItem: any) => {
          if (empItem.toPostingInCategoryCode === postingInItem.value) {
            empItem.postingIn = postingInItem.label; 
          }
        });

        this.department.forEach((departmentItem: any) => {
          if (empItem.toDepartmentId === departmentItem.value) {
            empItem.department = departmentItem.label; 
          }
        });

        this.designation.forEach((designationItem: any) => {
          if (empItem.toDesignationId === designationItem.value) {
            empItem.designation = designationItem.label; 
          }
        });
      });
      this.tableData = res.results.empList;
      
    });
      this.showMainTitle = false;
      this.showCard = false;
      this.showtable =  true;
      this.showFilter  = false; 
      this.showActive = true;
      this.showIcon = true;
      this.showGender = true;
      this.showPosting = true;
      this.showDesignation = true;
  }

  retiredOfficer(){
    this.leaveTransfer.getRetiresOfficers().subscribe((res: any) => {
      res.results.empList.forEach((empItem: any) => {
        this.postingIn.forEach((postingInItem: any) => {
          if (empItem.toPostingInCategoryCode === postingInItem.value) {
            empItem.postingIn = postingInItem.label; 
          }
        });

        this.department.forEach((departmentItem: any) => {
          if (empItem.toDepartmentId === departmentItem.value) {
            empItem.department = departmentItem.label; 
          }
        });

        this.designation.forEach((designationItem: any) => {
          if (empItem.toDesignationId === designationItem.value) {
            empItem.designation = designationItem.label; 
          }
        });
      });
      this.tableData = res.results.empList;
    });
    this.showMainTitle = false;
    this.showCard = false;
    this.showFilter  = false; 
    this.showtable = true;
    this.showretiredOfficer = true;
    this.showIcon = true;
    this.showGender = true;
    this.showPosting = true;
    this.showDesignation = true;
  }

  maleOfficer(){
    this.leaveTransfer.getMaleEmployees().subscribe((res: any) => {
      res.results.empList.forEach((empItem: any) => {
        this.postingIn.forEach((postingInItem: any) => {
          if (empItem.toPostingInCategoryCode === postingInItem.value) {
            empItem.postingIn = postingInItem.label; 
          }
        });

        this.department.forEach((departmentItem: any) => {
          if (empItem.toDepartmentId === departmentItem.value) {
            empItem.department = departmentItem.label; 
          }
        });

        this.designation.forEach((designationItem: any) => {
          if (empItem.toDesignationId === designationItem.value) {
            empItem.designation = designationItem.label; 
          }
        });
      });
      this.tableData = res.results.empList;
    });
    this.showMainTitle = false;
    this.showCard = false;
    this.showFilter  = false; 
    this.showtable = true;
    this.showMale = true;
    this.showIcon = true;
    this.showGender = false;
    this.showPosting = true;
    this.showDesignation = true;
  }

  femaleOfficer(){
    this.leaveTransfer.getFemaleEmployees().subscribe((res: any) => {
      res.results.empList.forEach((empItem: any) => {
        this.postingIn.forEach((postingInItem: any) => {
          if (empItem.toPostingInCategoryCode === postingInItem.value) {
            empItem.postingIn = postingInItem.label; 
          }
        });

        this.department.forEach((departmentItem: any) => {
          if (empItem.toDepartmentId === departmentItem.value) {
            empItem.department = departmentItem.label; 
          }
        });

        this.designation.forEach((designationItem: any) => {
          if (empItem.toDesignationId === designationItem.value) {
            empItem.designation = designationItem.label; 
          }
        });
      });
      this.tableData = res.results.empList;
    });
    this.showMainTitle = false;
    this.showCard = false;
    this.showFilter  = false; 
    this.showtable = true;
    this.showFemale = true;
    this.showIcon = true;
    this.showGender = false;
    this.showPosting = true;
    this.showDesignation = true;
  }

  secretariat(data:any){
    this.leaveTransfer.getSecretariat(data).subscribe((res) => {
      res.results.empList.forEach((empItem: any) => {
        this.department.forEach((departmentItem: any) => {
          if (empItem.toDepartmentId === departmentItem.value) {
            empItem.department = departmentItem.label; 
          }
        });

        this.designation.forEach((designationItem: any) => {
          if (empItem.toDesignationId === designationItem.value) {
            empItem.designation = designationItem.label; 
          }
        });
      });
      this.tableData = res.results.empList;
    });
    this.showMainTitle = false;
    this.showCard = false;
    this.showtable =  true;
    this.showFilter  = false; 
    this.showSec = true;
    this.showIcon = true;
    this.showPosting = false;
    this.showDesignation = true;
  }

  outsideSectrtariat(data:any){
    this.leaveTransfer.getSecretariat(data).subscribe((res)=>{
      res.results.empList.forEach((empItem: any) => {
        this.department.forEach((departmentItem: any) => {
          if (empItem.toDepartmentId === departmentItem.value) {
            empItem.department = departmentItem.label; 
          }
        });

        this.designation.forEach((designationItem: any) => {
          if (empItem.toDesignationId === designationItem.value) {
            empItem.designation = designationItem.label; 
          }
        });
      });
      this.tableData = res.results.empList;
    });
    this.showMainTitle = false;
    this.showCard = false;
    this.showtable =  true;
    this.showFilter  = false; 
    this.showOutsideSec = true;
    this.showIcon = true;
    this.showPosting = false;
    this.showDesignation = true;
  }

  chennaiOfficer(data:any){
    this.leaveTransfer.getByLocation(data).subscribe((res)=>{
      res.results.empList.forEach((empItem: any) => {
        this.postingIn.forEach((postingInItem: any) => {
          if (empItem.toPostingInCategoryCode === postingInItem.value) {
            empItem.postingIn = postingInItem.label; 
          }
        });

        this.department.forEach((departmentItem: any) => {
          if (empItem.toDepartmentId === departmentItem.value) {
            empItem.department = departmentItem.label; 
          }
        });

        this.designation.forEach((designationItem: any) => {
          if (empItem.toDesignationId === designationItem.value) {
            empItem.designation = designationItem.label; 
          }
        });
      });
      this.tableData = res.results.empList;
    });
    this.showMainTitle = false;
    this.showCard = false;
    this.showtable =  true;
    this.showFilter  = false; 
    this.showChennai = true;
    this.showIcon = true;
    this.showLocation = false;
    this.showGender = true;
    this.showPosting = true;
  }

  outsideChennai(data:any){
    this.leaveTransfer.getByLocation(data).subscribe((res)=>{
      res.results.empList.forEach((empItem: any) => {
        this.postingIn.forEach((postingInItem: any) => {
          if (empItem.toPostingInCategoryCode === postingInItem.value) {
            empItem.postingIn = postingInItem.label; 
          }
        });

        this.department.forEach((departmentItem: any) => {
          if (empItem.toDepartmentId === departmentItem.value) {
            empItem.department = departmentItem.label; 
          }
        });

        this.designation.forEach((designationItem: any) => {
          if (empItem.toDesignationId === designationItem.value) {
            empItem.designation = designationItem.label; 
          }
        });
      });
      this.tableData = res.results.empList;
    });
    this.showMainTitle = false;
    this.showCard = false;
    this.showtable =  true;
    this.showFilter  = false; 
    this.showOutsideChennai = true;
    this.showIcon = true;
    this.showLocation = true;
    this.showDesignation = true;
  }

  collectors(data:string){
    this.leaveTransfer.getByDesignation(data).subscribe((res: any) => {
      res.results.empList.forEach((empItem: any) => {
        this.department.forEach((departmentItem: any) => {
          if (empItem.toDepartmentId === departmentItem.value) {
            empItem.department = departmentItem.label; 
          }
        });

        this.postingIn.forEach((postingInItem: any) => {
          if (empItem.toPostingInCategoryCode === postingInItem.value) {
            empItem.postingIn = postingInItem.label; 
          }
        });
      });
     
      this.tableData = res.results.empList;
    });
    this.showMainTitle = false;
    this.showCard = false;
    this.showtable =  true;
    this.showFilter  = false; 
    this.showCollector = true;
    this.showIcon = true;
    this.showPosting = true;
    this.showGender = true;
    this.showDesignation = false;
  }

  subCollectors(data:string){
    this.leaveTransfer.getByDesignation(data).subscribe((res: any) => {
      res.results.empList.forEach((empItem: any) => {
        this.department.forEach((departmentItem: any) => {
          if (empItem.toDepartmentId === departmentItem.value) {
            empItem.department = departmentItem.label; 
          }
        });

        this.postingIn.forEach((postingInItem: any) => {
          if (empItem.toPostingInCategoryCode === postingInItem.value) {
            empItem.postingIn = postingInItem.label; 
          }
        });
      });
     
      this.tableData = res.results.empList;
    });
    this.showMainTitle = false;
    this.showCard = false;
    this.showtable =  true;
    this.showFilter  = false; 
    this.showSub = true;
    this.showIcon = true;
    this.showPosting = true;
    this.showGender = true;
    this.showDesignation = false;
  }

  asstCollectors(data:string){
    this.leaveTransfer.getByDesignation(data).subscribe((res: any) => {
      res.results.empList.forEach((empItem: any) => {
        this.department.forEach((departmentItem: any) => {
          if (empItem.toDepartmentId === departmentItem.value) {
            empItem.department = departmentItem.label; 
          }
        });

        this.postingIn.forEach((postingInItem: any) => {
          if (empItem.toPostingInCategoryCode === postingInItem.value) {
            empItem.postingIn = postingInItem.label; 
          }
        });
      });
     
      this.tableData = res.results.empList;
    });
    this.showMainTitle = false;
    this.showCard = false;
    this.showtable   =  true;
    this.showFilter  = false; 
    this.showAsst = true;
    this.showIcon = true;
    this.showPosting = true;
    this.showGender = true;
    this.showDesignation = false;
  } 

  additioanlCollector(data:string){
    this.leaveTransfer.getByDesignation(data).subscribe((res: any) => {
      res.results.empList.forEach((empItem: any) => {
        this.department.forEach((departmentItem: any) => {
          if (empItem.toDepartmentId === departmentItem.value) {
            empItem.department = departmentItem.label; 
          }
        });

        this.postingIn.forEach((postingInItem: any) => {
          if (empItem.toPostingInCategoryCode === postingInItem.value) {
            empItem.postingIn = postingInItem.label; 
          }
        });
      });
     
      this.tableData = res.results.empList;
    });
    this.showMainTitle = false;
    this.showCard = false;
    this.showtable   =  true;
    this.showFilter  = false; 
    this.showAdditional=true;
    this.showIcon = true;
    this.showPosting = true;
    this.showGender = true;
    this.showDesignation = false;
  }

  commissioner(data:string){
    this.leaveTransfer.getByDesignation(data).subscribe((res: any) => {
      res.results.empList.forEach((empItem: any) => {
        this.department.forEach((departmentItem: any) => {
          if (empItem.toDepartmentId === departmentItem.value) {
            empItem.department = departmentItem.label; 
          }
        });

        this.postingIn.forEach((postingInItem: any) => {
          if (empItem.toPostingInCategoryCode === postingInItem.value) {
            empItem.postingIn = postingInItem.label; 
          }
        });
      });
     
      this.tableData = res.results.empList;
    });
    this.showMainTitle = false;
    this.showCard = false;
    this.showtable   =  true;
    this.showFilter  = false; 
    this.showComm = true;
    this.showIcon = true;
    this.showPosting = true;
    this.showGender = true;
    this.showDesignation = false;
  }

  Back(){
    this.showMainTitle = true;
    this.showtable = false;
    this.showActive = false;
    this.showretiredOfficer = false;
    this.showMale = false;
    this.showFemale = false;
    this.showSec = false;
    this.showOutsideChennai = false;
    this.showOutsideSec = false;
    this.showChennai = false;
    this.showCollector = false;
    this.showSub = false;
    this.showAsst = false;
    this.showAdditional = false;
    this.showComm = false;
    this.showCard = true;
    this.showFilter = true;
    this.showIcon = false;
  }

  clearAll(){
    this.filterForm.reset();
  this.employeeFilterData = [];
  }
  
// createBarChart(){
//   this.chart = new Chart("MyBarChart", {
//      type: 'bar',

//      data: {
//        labels: ['2019', '2020', '2021','2022','2023' ], 
//                 datasets: [
//                  {
//                    label: "Transfer",
//                    data: ['467','576', '572', '79', '92'],
//                    backgroundColor: '#3d97ff'
//                  },
//                  {
//                    label: "Promotion",
//                    data: ['542', '542', '536', '327', '17'],
//                    backgroundColor: '#202b46'
//                  }  
//                ]
//      },
//      options: {
//        aspectRatio:2.5
//      }
     
//    });
//  }
//  createLineChart(){
//    this.chart = new Chart("MyLineChart", {
//       type: 'line',

//       data: {
//         labels: ['2019', '2020', '2021','2022','2023' ], 
//          datasets: [
//           {
//             label: "Transfer",
//             data: ['467','576', '572', '79', '92'],
//             backgroundColor: '#3d97ff'
//           },
//           {
//             label: "Promotion",
//             data: ['542', '542', '536', '327', '17'],
//             backgroundColor: '#202b46'
//           }  
//         ]
//       },
//       options: {
//         aspectRatio:2.5
//       }
      
//     });
//   }

}
