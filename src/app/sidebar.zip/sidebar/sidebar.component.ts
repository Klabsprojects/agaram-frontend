import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LeaveTransferService } from '../forms/forms.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.css'
})
export class SidebarComponent implements OnInit {
  showSubMenu = false;
  activeSubMenu: string | null = null;
  constructor(private router: Router, private menuService:LeaveTransferService) { }

  ngOnInit(): void {
  }

  isActive(route: string): boolean {
    return this.router.isActive(route, true);
  }

  onItemClick(item: string) {
    this.menuService.setSelectedItem(item);
  }

 

  toggleSubMenu(section: string) {
    this.showSubMenu = true;
    this.activeSubMenu = section;
  }

}
